// index.js
console.log('Hello, World! Node is working...');

// set variable to reffer to the express package
// instatitage it in a nother variable called app
const express = require('express');
const app = express();
var http = require('http');
var url = require('url');

function fullUrl(req) {
  return url.format({
    protocol: req.protocol,
    host: req.get('host'),
    pathname: req.originalUrl
  });
}

app.get('/', (req, res) => { // new
    res.send('Homepage! Hello world.');
  });

  
app.get('/About', (req, res) => { // new
    res.send('About! Hello world about.');
  });

app.get('/Test', (req, res) => { // new
  res.setHeader('Content-Type', 'application/json');
  res.send(fullUrl(req))
  //res.end(JSON.stringify({ a: 1 }));
});




app.listen(3000, () => console.log('listening on port 3000')); // new
